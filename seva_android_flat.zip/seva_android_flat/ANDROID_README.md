
Seva - Android Studio Ready Package (placeholder)

This package contains the web (www) assets and Capacitor config needed to create an Android project.
To generate the Android project and APK on your machine, follow these steps:

1. Ensure Node.js, npm, Ionic CLI, Capacitor CLI, Java JDK, and Android Studio are installed.
2. In this folder, install dependencies:
   npm install
3. Build the web assets:
   npm run build
   (or) copy the contents of 'public/' into 'www/' if not using React build.
4. Add Android with Capacitor:
   npx cap add android
5. Copy the web assets into the native project:
   npx cap copy android
6. Open Android Studio:
   npx cap open android
7. In Android Studio: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
   The unsigned debug APK will be in android/app/build/outputs/apk/debug/

Notes:
- This package does NOT include the native 'android' folder by default. Capacitor will create it on your machine in step 4.
- You can use the debug APK for quick testing; to publish to Play Store you must sign with your keystore.
