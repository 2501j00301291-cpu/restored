Seva - Ionic React wrapper

This project wraps your uploaded HTML into an Ionic React project.

How to use:
1. Install dependencies: npm install
2. Start dev server: npm start
3. Build: npm run build
4. Add Capacitor Android: npx cap add android
5. Open Android Studio: npm run android

Note: Supabase key and other secrets are embedded in your HTML (public/index.html). Consider moving them to environment variables before production.
