import React from 'react';
import { IonApp } from '@ionic/react';

const App = () => {
  return (
    <IonApp>
      {/* The UI is provided by public/index.html - this App keeps Ionic available. */}
      <div id="seva-react-root"></div>
    </IonApp>
  );
};

export default App;
