const config = {
  appId: 'com.seva.app',
  appName: 'Seva',
  webDir: 'build',
  bundledWebRuntime: false
};

export default config;
