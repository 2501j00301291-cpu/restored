
#!/bin/bash
# Build instructions for Seva APK (run in project root)
set -e
echo "1) Install dependencies"
npm install
echo "2) Build web assets"
npm run build
echo "3) Add Android platform (if not already added)"
npx cap add android || true
echo "4) Copy web assets to Android"
npx cap copy android
echo "5) Open Android Studio"
echo "Run: npx cap open android  (then Build > Build APK(s) inside Android Studio)"
