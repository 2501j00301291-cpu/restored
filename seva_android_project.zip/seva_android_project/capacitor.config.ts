const config = {
  appId: 'com.seva.app',
  appName: 'Seva',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
